/*
	Authors:	Jessio D'souza		RollNo: 1612
				Archie Fernandes	RollNo:	1613
				
	Date Created:	3rd April 2017.
	Date Modified:	7th April 2017.
	Date Modified:	19th April 2017.//Validations for string and numbers
	
	Future Implementation:	Delete function and Undo. 

*/
#include "trie.h"

void main()
{
	system("clear");
	// Local Definitions
	TrieType trie;
	NodePtrType found_node=NULL;
	char element[15],name[15],state[10],city[10];
	int response,found,i=0,count=0,flag,resp;
	char num[12];
	char msg[50]="\tPhoneBook Implementation using Tries.";

	FILE *fp;

	trie=CreateTrie();
	if(trie==NULL)
	{
		printf("\nTrie is not created\n");
		return;
	}
	trie=retrive_details(trie);
	PrintIntro(msg);
	// Statements
	do
	{
		flag=1;
		printf("\n_____________________________________________________________________________\n");
		printf("\n1-Insert Record\n2-Retrieve details\n3-Display records\n4-Find Number\n5-Change Details\n6-Terminate\n");
		printf("\nEnter Choice(1/2/3/4): ");
		scanf("%d",&response);
		switch(response){
			case 1:
				printf("\nEnter Phone Number to be inserted: ");
				while(flag==1)
				{
					scanf("%s",&element);
					flag=checkInt(element);//to validate integer
					if(flag==1)
						printf("Invalid Phone Number, Enter Again: ");
				}
				Find_Details(trie,element,&found);
				if(found==1)
					printf("\nPhone Numbers Already Exists \n");
				else
				{
					printf("\nEnter Name: \n");
					flag=1;				
					while(flag==1)
					{
						getchar();
						scanf("%[^\n]s",name);
						//printf("\nName: %s ",name);
						flag=chkstr(name);//to validate name
						if(flag==1)
							printf("Invalid Contact Name!!\nEnter Again Without Spaces: ");
					}
				
					printf("\nEnter state: \n");
					flag=1;
					while(flag==1)
					{
						getchar();
						scanf("%[^\n]s",state);
						
						flag=chkstr(state);//to validate state
						if(flag==1)
							printf("Invalid state!!\nEnter Again Without Spaces: ");
					}
					
					printf("\nEnter city: \n");
					flag=1;
					while(flag==1)
					{
						getchar();
						scanf("%[^\n]s",city);
						
						flag=chkstr(city);//to validate city
						if(flag==1)
							printf("Invalid city!!\nEnter Again Without Spaces: ");
					}
					trie=Insertword(trie,element, name,state, city);
					printf("\nNumber added to the Phonebook\n");
				}
			break;
			case 2:
				printf("\nEnter Phone Number to Retrieve Details: ");
				scanf("%s",&element	);
				found_node=Find_Details(trie,element, &found);
				if(found==1)
				{
					printf("\nRecord Found \n");
					//printf("\ncharacter at last node is %c\n",found_node->key);
					printf("\nPhone No.: %s		",element);
					printf("\nName : %s\n",(char*)found_node->name);
					printf("City : %s\n",(char*)found_node->city);
					printf("State : %s\n",(char*)found_node->state);
				}
				else
					printf("\nRecord Not Found \n");
			break;

			case 3:
					Display_records(trie -> rchild,num,&i);
					i=0;
			break;
			case 4:
					printf("\nEnter Name: \n");
					scanf("%s",name);
					find_Number(trie -> rchild,num,&i,name);
					
			break;
			case 5:
				printf("\nEnter Phone Number to Change Details: ");
				scanf("%s",&element);
				found_node=Find_Details(trie,element, &found);
			
			if(found==1)
				{
					printf("\nEnter 1 to change Name: ");
					scanf("%d",&resp);
					if(resp==1)
					{
						printf("\nEnter New name \n");
						flag=1;
						while(flag==1)
						{
							getchar();
							scanf("%[^\n]s",name);
							
							flag=chkstr(name);//to validate name
							if(flag==1)
							{
								printf(" Invalid Contact Name!!\nEnter Again Without Spaces: ");
							}
							
						}
						strcpy(found_node->name,name);
					}
					
					printf("\nEnter 1 to change State: ");
					scanf("%d",&resp);
					if(resp==1)
					{
						printf("\nEnter state: \n");
						flag=1;
						while(flag==1)
						{
							getchar();
							scanf("%[^\n]s",state);
							
							flag=chkstr(state);//to validate state
							if(flag==1)
								printf("Invalid state!!\nEnter Again Without Spaces: ");
						}
						strcpy(found_node->state,state);
					}
					
					printf("\nEnter 1 to change city: ");
					scanf("%d",&resp);
					if(resp==1)
					{
						printf("\nEnter city: \n");
						flag=1;
						while(flag==1)
						{
							getchar();
							scanf("%[^\n]s",city);
							
							flag=chkstr(city);//to validate city
							if(flag==1)
								printf("Invalid city!!\nEnter Again Without Spaces: ");
						}
						strcpy(found_node->city,city);
					}
					

					printf("\nRecord Modified Successfully\n");
				}
				else
					printf("\nRecord Not Found \n");
			break;
			case 6:
				fp=fopen("phonebook.txt","w");
				fclose(fp);				
				store_details(trie -> rchild,num,&i,&count);
				printf("\n%d Records Stored To Database\n",count);
			break;
			default: printf("\nInvalid Choice\n");
		}
		printf("\n_____________________________________________________________________________\n");
	}while(response!=6); 
	TerminateProgram();
}
