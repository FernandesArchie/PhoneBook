/*
	Jessio
	
	Data Structure design
	Display_records()
	CreateTrie();
	CreateNode(char element);
	Insertword(TrieType trie,char element[],char name[],char state[],char city[])
	retrive_details(TrieType trie)
	Find_Details(TrieType trie,char element[],int *found)

	Archie
	
	ChangeDetails
	store_details
	find_number using name
	checkInt(char string[])
	chkstr(char string[])
	PrintIntro(char msg[]);
	TerminateProgram();

*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

typedef struct Node{
	char key;
	char name[20];
	char state[10];
	char city[10];
	int word;
	//void* name;
	struct Node* sibbling;
	struct Node* child;
}NodeType;
typedef NodeType * NodePtrType;
typedef struct Root{
	int count;
	NodePtrType rchild;
	//int(*compare)(void*,void*);
	//void(*print_element)(void*);
}HeaderType;
typedef HeaderType* TrieType;
TrieType trie;

void Display_records(NodePtrType curr,char num[],int *i);

TrieType CreateTrie();
NodePtrType CreateNode(char element);

TrieType Insertword(TrieType trie,char element[],char name[],char state[],char city[]);
TrieType retrive_details(TrieType trie);

NodePtrType Find_Details(TrieType trie,char element[],int *found);
void store_details(NodePtrType cur,char num[],int *i,int *count);
void find_Number(NodePtrType cur,char num[],int *i,char name[]);

//Functions from Validatefunc.c file
int checkInt(char string[]);
int chkstr(char string[]);
void PrintIntro(char msg[]);
void TerminateProgram();
/*
Function to be written

function to allocate memory for node and store valuse and retrtn node

Function to check if word is present in dictionary (need for insert too "Pre condition")
*/
