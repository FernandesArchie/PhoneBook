#include "trie.h"

int checkInt(char string[])//Validate Integer
{
	int flag=0,i=0,l=0;
	l=strlen(string);
	while(flag==0 && i<=l-1)
	{
		if(!(string[i]>='0' && string[i]<='9'))
			flag = 1;
		else
			i++;
	}
	if(i>10)
		flag=1;
	return flag;
}

int chkstr(char string[])//Validate string,checks if more then 1 word entered in a string.
{
	int flag=0,i=0,l=0;
	l=strlen(string);
	while(flag==0 && i<=l-1)
	{
		if(string[i]==' ')
			flag = 1;
		else
			i++;
	}
	return flag;
}

void PrintIntro(char msg[])
{
	printf("\n******************************************************************************\n");
	printf("\n\t\t\tData Structures Project");
	printf("\n1612-Jessio D'Souza                                      1613-Archie Fernandes\n");
	printf("\n\t\t%s\n",msg);
	printf("\n******************************************************************************\n");
}

void TerminateProgram()
{
	printf("\n******************************************************************************\n");
	printf("\n\t\t\tThank You For using this program\n");
	printf("\n******************************************************************************\n");
}