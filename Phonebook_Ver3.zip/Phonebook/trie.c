 #include "trie.h"
 
 //Create Trie
TrieType CreateTrie()
{
	TrieType trie;
	trie=(TrieType)malloc(sizeof(HeaderType));
	if(trie==NULL)
	{
		printf("\n ERROR:Could not allocate space\n");
		exit(1);
	}
	trie->count=0;
	trie->rchild=NULL;
	//trie->print_element=print_element;
	return trie;
}

NodePtrType CreateNode(char element)
{
	//char *newname
	//newname=(char*)malloc(sizeof(char));	
	NodePtrType newnode;

	//newname= name;
	newnode = (NodePtrType)malloc(sizeof(NodeType));
	if(newnode!=NULL)
	{	
		
		newnode -> key = element;
		//newnode -> name=(char*)name;
		newnode -> word = 0;
		newnode -> sibbling = NULL;
		newnode -> child = NULL;
	}
	return newnode;
}
//********PRE CONDITIONS: Called only if element variable is not empty AND word is not present in the Dictionary**********
//TrieType Insertword(TrieType trie,char element[])
TrieType Insertword(TrieType trie,char element[],char name[],char state[],char city[])
{
	NodePtrType cur,temp,newnode;
	temp=trie->rchild;
	int i=0,c=0;
	//will go in loop till it checks how many characters of the word are present in d list
	while(temp!=NULL && i <strlen(element))
	{
		if(temp->key==element[i])
		{	//this condition will move pointer downwards
			cur=temp;
			temp=temp->child;
			c=1;
			i++;
		}
		else
		{	//this condition will move pointer to the right
			cur=temp;
			c=0;
			temp=temp->sibbling;
		}
	}
	//insert part
	if(i<strlen(element))
	{
		if(trie->rchild==NULL)
		{	//If inserting first node
			newnode=CreateNode(element[i]);
			if(newnode==NULL)
			{ 
				printf("\n ERROR:Could not allocate space\n");
				exit(1);
			}
			else
			{
				trie->rchild=newnode;
				//printf("%c ",trie->rchild->key);
				temp=cur;
				cur=trie->rchild;
			}
		}
		else
		{	//Inserting sibbling node
			newnode=CreateNode(element[i]);
			if(newnode==NULL)
			{
				printf("\n ERROR:Could not allocate space\n");
				exit(1);
			}
			else
			{
				if(c==0)//if c is 0 insert node to Right
				{
					cur->sibbling=newnode;
					//printf("%c ",cur->sibbling->key);
					cur=cur->sibbling;
				}
				else
				{
					cur->child=newnode;
					//printf("%c ",cur->child->key);
					cur=cur->child;
				}
			}
		}
		i++;
	}
	
	while(i<strlen(element))
	{	//keeps adding new node downwards(child)
		newnode=CreateNode(element[i]);
		if(newnode==NULL)
		{
			printf("\n ERROR:Could not allocate space\n");
			exit(1);
		}
		else
		{
			cur->child=newnode;
			//printf("%c ",cur->child->key);
			cur=cur->child;
		}
		i++;
	}
	cur->word=1;
	strcpy(newnode->name,name);
	strcpy(newnode->state,state);
	strcpy(newnode->city,city);
return trie;
}

//Searches Records based on Phone number
NodePtrType Find_Details(TrieType trie,char element[],int *found)
{
	*found=0;
	NodePtrType cur,temp,newnode,found_node;
	cur=trie->rchild;
	int i=0;
	//will go in loop till it checks how many characters of a word are present in d list
	while(cur!=NULL && i <strlen(element))
	{	
		if(cur->key==element[i])
		{	//this condition will move pointer downwards
			temp=cur;			
			cur=cur->child;
			i++;
		}
		else
		{	//this condition will move pointer to the right
			temp=cur;
			cur=cur->sibbling;
		}
	}
	if(i==(strlen(element)) && temp->word==1)
	{
		*found=1;
		found_node=temp;	//To return the Node
	}
	return found_node;
}

//Displays the entire Trie
void Display_records(NodePtrType cur,char num[],int *i)
{
	int j;
	if(cur==NULL)
	{
		*i=*i-1;
		return;
	}
	num[*(int *)i]=cur->key;
	*i=*i+1;
	
	if(cur->word==1)
	{	
		printf("\n\nNumber:- ");
		for(j=0;j<*(int *)i;j++)
			printf("%c",num[j]);
		printf("\nName:- %s",cur -> name);
		printf("\nState:- %s",cur -> state);
		printf("\nCity:- %s",cur -> city);
	}
	Display_records(cur -> child,num,i);
	Display_records(cur -> sibbling,num,i);
	
}

//Searches and Displays all Records of a given Name
void find_Number(NodePtrType cur,char num[],int *i,char name[])
{
	int j,n;
	if(cur==NULL)
	{
		*i=*i-1;
		return;
	}
	num[*(int *)i]=cur->key;
	*i=*i+1;
	
	if(cur->word==1 )
	{	
		if(strcmp(cur->name,name)==0)
		{
			printf("\n\nNumber:- ");
			for(j=0;j<*(int *)i;j++)
				printf("%c",num[j]);
			printf("\nName:- %s",cur -> name);
			printf("\nState:- %s",cur -> state);
			printf("\nCity:- %s",cur -> city);
		}
	}
	find_Number(cur -> child,num,i,name);
	find_Number(cur -> sibbling,num,i,name);
}


//for transfering into a file
void store_details(NodePtrType cur,char num[],int *i,int *count)
{
	FILE *fp;
	int j;
	if(cur==NULL)
	{
		*i=*i-1;
		return;
	}
	num[*(int *)i]=cur->key;
	*i=*i+1;
	
	if(cur->word==1)
	{	fp=fopen("phonebook.txt","a");
		num[*(int *)i]='\0';
		*count=*count+1;
		fprintf(fp,"%s %s %s %s \n",num,cur -> name,cur -> state,cur -> city);
		fclose(fp);
	}
	store_details(cur -> child,num,i,count);
	store_details(cur -> sibbling,num,i,count);
}

//Brings Data from File to the Program
TrieType retrive_details(TrieType trie)
{
	int n,count=0;
	char element[15],name[15],state[10],city[10];
	FILE *fp;
	fp = fopen("phonebook.txt", "rt");
	if(fp == NULL) 
		printf("File not found");
	else{
		while (n=(fscanf(fp,"%s %s %s %s \n",element,name,state,city))!= EOF)
		{	
			count++;
			//printf("%s %s %s %s \n",element,name,state,city);
			trie=Insertword(trie,element,name,state,city);
		}
	}
	printf("\n%d Records Loaded from Database\n",count);
	fclose(fp);
    return trie;
}


/*
TrieType Delete_word(TrieType trie,char element)
{
}
TrieType Undo(TrieType trie,Trietype temp)
{
}
*/
